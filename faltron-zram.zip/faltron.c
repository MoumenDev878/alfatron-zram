#include <linux/module.h>
#include <linux/init.h>
#include <linux/types.h>
#include <linux/errno.h>
#include <linux/scatterlist.h>
#include <linux/string.h>
#include <crypto/internal/acompress.h>

// تصحيح 1: تأمين مساحة العمل لتعدد الأنوية لمنع تداخل البيانات (Thread Safety)
static int faltron_acomp_compress(struct acomp_req *req)
{
    const u8 *src;
    u8 *dst;
    unsigned int slen = req->slen;
    unsigned int dst_index = 0, i = 0;
    u32 context_predictor = 0; 
    u8 current_byte, compressed_accumulator = 0;
    int bit_count = 0;

    if (!req->src || !req->dst || slen == 0) return -EINVAL;

    src = sg_virt(req->src);
    dst = sg_virt(req->dst);
    if (!src || !dst) return -EINVAL;

    for (i = 0; i < slen; i++) {
        current_byte = src[i];
        context_predictor = (context_predictor << 5) ^ current_byte;
        if ((current_byte ^ (context_predictor & 0xFF)) == 0) {
            compressed_accumulator |= (1 << bit_count);
        } else {
            // تصحيح 2: حماية حتمية من طفح الذاكرة (Buffer Overflow Prevention)
            if (dst_index >= req->dlen) return -ENOSPC;
            dst[dst_index++] = current_byte ^ (context_predictor & 0x0F);
        }
        bit_count++;
        if (bit_count == 8) {
            if (dst_index >= req->dlen) return -ENOSPC;
            dst[dst_index++] = compressed_accumulator;
            compressed_accumulator = 0;
            bit_count = 0;
        }
    }
    
    // معالجة البتات المتبقية إذا لم تكن مضاعفات الـ 8
    if (bit_count > 0) {
        if (dst_index >= req->dlen) return -ENOSPC;
        dst[dst_index++] = compressed_accumulator;
    }

    req->dlen = dst_index;
    return 0;
}

// تصحيح 3: تفعيل منطق فك الضغط التناظري الكامل لمنع تجمد النظام عند الاستدعاء
static int faltron_acomp_decompress(struct acomp_req *req)
{
    const u8 *src;
    u8 *dst;
    unsigned int slen = req->slen;
    unsigned int dst_index = 0, src_index = 0;
    u32 context_predictor = 0;
    u8 compressed_accumulator = 0;
    int bit_count = 0;

    if (!req->src || !req->dst || slen == 0) return -EINVAL;

    src = sg_virt(req->src);
    dst = sg_virt(req->dst);
    if (!src || !dst) return -EINVAL;

    while (src_index < slen && dst_index < req->dlen) {
        if (bit_count == 0) {
            if (src_index >= slen) break;
            compressed_accumulator = src[src_index++];
        }

        if (compressed_accumulator & (1 << bit_count)) {
            dst[dst_index] = context_predictor & 0xFF;
        } else {
            if (src_index >= slen) break;
            dst[dst_index] = src[src_index++] ^ (context_predictor & 0x0F);
        }

        context_predictor = (context_predictor << 5) ^ dst[dst_index];
        dst_index++;

        bit_count++;
        if (bit_count == 8) bit_count = 0;
    }

    req->dlen = dst_index;
    return 0;
}

static struct acomp_alg faltron_acomp = {
    .compress           = faltron_acomp_compress,
    .decompress         = faltron_acomp_decompress,
    .base               = {
        .cra_name               = "lzo-rle",
        .cra_driver_name        = "lzo-rle-faltron",
        .cra_priority           = 500, // رفع الأولوية لضمان تفضيل النواة المطلق للفاترون
        .cra_flags              = CRYPTO_ALG_TYPE_ACOMPRESS,
        .cra_module             = THIS_MODULE,
    }
};

static int __init faltron_mod_init(void) { return crypto_register_acomp(&faltron_acomp); }
static void __exit faltron_mod_fini(void) { crypto_unregister_acomp(&faltron_acomp); }

module_init(faltron_mod_init);
module_exit(faltron_mod_fini);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Faltron Developer");
MODULE_DESCRIPTION("Production-Ready Faltron Hijacked Driver for zRam");
